﻿using Flunt.Notifications;

namespace Infra.Shared.Contexts
{
    public class NotificationContext : Notifiable
    {
    }
}
